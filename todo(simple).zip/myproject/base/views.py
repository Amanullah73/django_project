from turtle import title
from django.shortcuts import render,redirect
from .models import *



# Create your views here.


def home(request):
    data = TaskModel.objects.all()
    return render(request,'home.html',{'data':data})


def add(request):
    if request.method == 'POST':
        # print(title,desc)
        TaskModel.objects.create(
            title = request.POST['title'],
            desc =  request.POST['desc']
        )
        return redirect('home')
        
    return render(request,'add.html')


def update(request,pk):
    data = TaskModel.objects.get(id=pk)

    if request.method == 'POST':
        title = request.POST['title']
        desc = request.POST['desc']
        data.title = title
        data.desc = desc
        data.save()
        return redirect('home')
    return  render(request,'update.html',{'data':data})


def complete(request):
    a =  CompleteModel.objects.all()
    return render(request,'complete.html',{'data':a})


def trash(request):
    a = TrashModel.objects.all()
    return render(request,'trash.html',{'data':a})


#-------------------------------------------------------home page-----------------------------------------------------

#HOME PAGE COMPLETE BUTTON
def complete_(request,pk):
    a = TaskModel.objects.get(id=pk) #fletch the record from the data base

    CompleteModel.objects.create(
        title=a.title,
        desc = a.desc
    )#create the record in the complete databse

    a.delete()# delete the record from the taskmodel
    return redirect('home')

#delete button on the homepage
def delete(request,pk): 
    a = TaskModel.objects.get(id=pk) #fletch the record from the data base

    TrashModel.objects.create(
        title=a.title,
        desc = a.desc
    )#create the record in the trash databse

    a.delete()# delete the record from the taskmodel
    return redirect('home')

#delete all button on the homepage
def hdeleteall(request):
    a = TaskModel.objects.all()
    for i in a:
        TrashModel.objects.create(
            title = i.title,
            desc = i.desc
        )
        i.delete()
    return  redirect('home')

#complete all button on the homepage
def hcompleteall(request):
    a = TaskModel.objects.all()
    for i in a:
        CompleteModel.objects.create(
            title = i.title,
            desc = i.desc
        )
        i.delete()
    return  redirect('home')




#on home page create complete all button
#on complete page create delete button, delete_all button
#on delete page create delete button, delete_all button


#------------------------------------complete page---------------------------------------------------------------------


#delete button on the complete page
def cdelete(request,pk):
    a = CompleteModel.objects.get(id=pk)
    TrashModel.objects.create(
        title = a.title,
        desc = a.desc
    )
    a.delete()
    return redirect('complete')


#restore button on the complete page
def crestore(request,pk):
    a = CompleteModel.objects.get(id=pk)
    TaskModel.objects.create(
        title = a.title,
        desc = a.desc
    )
    a.delete()
    return redirect('complete')



#restore all button complete page
def crestore_all(request):
    a = CompleteModel.objects.all()
    for i in a:
        TaskModel.objects.create(
            title = i.title,
            desc = i.desc
        )
    a.delete()
    return redirect('home')



#delete all button on the complete page
def cdeleteall(request):
    a = CompleteModel.objects.all()
    for i in a:
        TrashModel.objects.create(
            title=i.title,
            desc=i.desc
        )
        i.delete()
    return redirect('complete')





#-----------------------------------------Trash page------------------------------------------------------





#restore button on the trash page
def trestore(request,pk):
    a = TrashModel.objects.get(id=pk)
    TaskModel.objects.create(
        title = a.title,
        desc = a.desc
    )
    a.delete()
    return redirect('home')

#delete button on the trash page
def tdelete(request,pk):
    a = TrashModel.objects.get(id=pk)
    a.delete()
    return redirect('trash')


#restore all button on the trash page
def trestoreall(request):
    a = TrashModel.objects.all()
    for i in a:
        TaskModel.objects.create(
            title = i.title,
            desc = i.desc
        )
    a.delete()
    return redirect('home')



#delete all button on the trash page
def tdeleteall(request):
    a = TrashModel.objects.all()
    a.delete()
    return  redirect('trash')







def about(request):
    return render(request,'about.html')