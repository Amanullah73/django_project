from django.urls import path
from .views import *

urlpatterns = [
    path('',home,name='home'),
    path('add/',add,name='add'),
    path('complete/',complete,name='complete'),
    path('trash/',trash,name='trash'),
    path('about/',about,name='about'),


    path('update/<int:pk>',update,name='update'),#update the record

#---------------------homepage url-------------------------------------------------------------------------
    path('delete/<int:pk>',delete,name='delete'), #home page delete button
    path('complete_/<int:pk>',complete_,name='complete_'), #home page complete button
    path('hdeleteall/',hdeleteall,name='hdeleteall'),#delete_all buttonn for homepage
    path('hcompleteall/',hcompleteall,name='hcompleteall'),#completeall button on the home page


#-----------------------complete page url------------------------------------------------------------
    path('cdelete/<int:pk>',cdelete,name='cdelete'), #delete button on the complete page
    path('crestore/<int:pk>',crestore,name='crestore'), #restore button on the complete page
    path('crestore_all/',crestore_all,name='crestore_all'),#restore button on the complete page
    path('cdeleteall/',cdeleteall,name='cdeleteall'), #delete all button on the complete page 


#------------------------------------------trash page  URL----------------------------------------------


    path('trestore/<int:pk>',trestore,name='trestore'),#restore button on the trash
    path('tdelete/<int:pk>',tdelete,name='tdelete'),#delete button on the trash
    path('trestoreall/',trestoreall,name='trestoreall'),#retore alla button on the trashpage
    path('tdeleteall/',tdeleteall,name='tdeleteall'),#delete alla button on the trashpage

]